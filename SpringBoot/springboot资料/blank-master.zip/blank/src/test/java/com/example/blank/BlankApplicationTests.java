package com.example.blank;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlankApplicationTests {

}
