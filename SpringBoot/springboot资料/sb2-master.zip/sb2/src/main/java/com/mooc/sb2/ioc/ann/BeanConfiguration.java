//package com.mooc.sb2.ioc.ann;
//
//import com.mooc.sb2.ioc.xml.Animal;
//import com.mooc.sb2.ioc.xml.Dog;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//public class BeanConfiguration implements SuperConfiguration{
//
////    @Bean("dog")
////    Animal getDog() {
////        return new Dog();
////    }
//
//}
//
