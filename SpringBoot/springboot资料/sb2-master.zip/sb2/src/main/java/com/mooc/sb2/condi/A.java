package com.mooc.sb2.condi;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
//@ConditionalOnProperty("com.mooc.condition")
//@MyConditionAnnotation({"com.mooc.condition1", "com.mooc.condition2"})
public class A {
}
