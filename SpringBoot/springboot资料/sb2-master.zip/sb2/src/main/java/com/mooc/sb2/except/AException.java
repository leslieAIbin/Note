package com.mooc.sb2.except;

public class AException extends Exception {

    public AException(Throwable cause) {
        super(cause);
    }
}
