package com.mooc.sb2.event;

public abstract class WeatherEvent {

    public abstract String getWeather();

}
