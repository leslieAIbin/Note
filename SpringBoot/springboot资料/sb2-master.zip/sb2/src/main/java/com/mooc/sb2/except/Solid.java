package com.mooc.sb2.except;

public class Solid {
}
