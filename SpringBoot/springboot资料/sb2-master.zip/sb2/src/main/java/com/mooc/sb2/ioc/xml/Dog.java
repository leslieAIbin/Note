package com.mooc.sb2.ioc.xml;

public class Dog extends Animal {
    @Override
    String getName() {
        return "dog";
    }
}
