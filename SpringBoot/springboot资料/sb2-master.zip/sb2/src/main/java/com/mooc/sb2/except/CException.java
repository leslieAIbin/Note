package com.mooc.sb2.except;

public class CException extends Exception {

    public CException(Throwable cause) {
        super(cause);
    }
}
