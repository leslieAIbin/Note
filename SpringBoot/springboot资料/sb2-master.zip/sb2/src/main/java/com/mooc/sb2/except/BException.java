package com.mooc.sb2.except;

public class BException extends Exception {

    public BException(Throwable cause) {
        super(cause);
    }
}
