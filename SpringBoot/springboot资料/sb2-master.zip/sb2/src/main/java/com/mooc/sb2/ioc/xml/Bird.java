package com.mooc.sb2.ioc.xml;

public class Bird extends Animal {
    @Override
    String getName() {
        return "bird";
    }
}
