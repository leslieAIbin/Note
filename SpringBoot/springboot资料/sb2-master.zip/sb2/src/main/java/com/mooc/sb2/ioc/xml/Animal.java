package com.mooc.sb2.ioc.xml;

public abstract class Animal {

    abstract String getName();

}
