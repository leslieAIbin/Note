package com.mooc.sb2.event;

public interface WeatherListener {

    void onWeatherEvent(WeatherEvent event);

}
