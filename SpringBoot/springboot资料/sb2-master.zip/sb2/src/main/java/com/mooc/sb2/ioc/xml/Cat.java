package com.mooc.sb2.ioc.xml;

public class Cat extends Animal {
    @Override
    String getName() {
        return "cat";
    }
}
